<?php

    $config = array(

        'database' => array(
            'host' => 'localhost',
            'username' => 'phpmyadmin',
            'password' => 'phpmyadmin',
            'database' => 'GALLERY2',
            'encoding' => 'utf8',
        ),
    );


?>